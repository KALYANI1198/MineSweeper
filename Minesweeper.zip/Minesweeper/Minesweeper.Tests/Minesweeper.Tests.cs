﻿using Xunit;

namespace Minesweeper.Tests
{
    public class MinesweeperTests
    {
        [Fact]
        public void TryParseSelectedCell_ValidInput_ParsesSuccessfully()
        {
            // Arrange
            var gridSize = 3;
            var minesweeper = new Minesweeper(new FakeInputProvider("A2"));

            // Act
            var result = minesweeper.TryParseSelectedCell("A2", gridSize, out var row, out var col);

            // Assert
            Assert.True(result);
            Assert.Equal(0, row);
            Assert.Equal(1, col);
        }

        [Fact]
        public void PlaySingleGame_MineDetonated_GameOver()
        {
            // Arrange
            var minefield = new char[,] { { 'X' } };
            var gridSize = 1;
            var numMines = 1;
            var inputProvider = new FakeInputProvider("A1");
            var minesweeper = new Minesweeper(inputProvider);

            // Act
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                minesweeper.PlaySingleGame(minefield, gridSize, numMines);
                var result = sw.ToString().Trim();

                // Assert
                Assert.Contains("Oh no, you detonated a mine! Game over.", result);
            }
        }

        [Fact]
        public void PlaySingleGame_WinGame_CongratulationsMessage()
        {
            // Arrange
            var minefield = new char[,] { { '0', '1' }, { 'X', '2' } };
            var gridSize = 2;
            var numMines = 1;
            var inputProvider = new FakeInputProvider("A2", "B2","A1");
            var minesweeper = new Minesweeper(inputProvider);

            // Act
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                minesweeper.PlaySingleGame(minefield, gridSize, numMines);
                var result = sw.ToString().Trim();

                // Print the captured output for inspection
                Console.WriteLine(result);
                // Assert
                Assert.Contains("Congratulations, you have won the game!", result);
            }
        }


    }

}
