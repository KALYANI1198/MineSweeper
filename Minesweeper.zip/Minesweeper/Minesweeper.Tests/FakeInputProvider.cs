﻿using Minesweeper.Interfaces;

namespace Minesweeper.Tests
{
    public class FakeInputProvider : IInputProvider
    {
        private readonly string[] _inputs;
        private int _index;

        public FakeInputProvider(params string[] inputs)
        {
            _inputs = inputs;
            _index = 0;
        }

        public string GetInput()
        {
            if (_index < _inputs.Length)
            {
                return _inputs[_index++];
            }

            return string.Empty;
        }
    }
}
