﻿using Minesweeper.Interfaces;

namespace Minesweeper
{
    public class Program
    {
          static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Welcome to Minesweeper!\n");

                int sizeofGrid = Minesweeper.CalculateGridSize();
                int maxMines = (int)(sizeofGrid * sizeofGrid * 0.35);
                int numMines = Minesweeper.CountMinesNumber(maxMines);

                char[,] minefield = Minesweeper.InitializeDefaultMinefield(sizeofGrid);
                Minesweeper.PlaceMines(minefield, numMines);

                IInputProvider inputProvider = new ConsoleInputProvider();
                var minesweeper = new Minesweeper(inputProvider);
                minesweeper.PlaySingleGame(minefield, sizeofGrid, numMines);

                Console.WriteLine("Press any key to play again...");
                Console.ReadKey();
            }
        }
    }
}
