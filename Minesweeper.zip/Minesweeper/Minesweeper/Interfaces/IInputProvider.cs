﻿namespace Minesweeper.Interfaces
{    public interface IInputProvider
    {
        string GetInput();
    }
}
