﻿namespace Minesweeper.Interfaces
{
    public class ConsoleInputProvider : IInputProvider
    {
        public string GetInput()
        {
            Console.Write("Select a square to reveal (e.g. A1): ");
            return Console.ReadLine().ToUpper();
        }
    }
}
