﻿using Minesweeper.Interfaces;

namespace Minesweeper
{
    public class Minesweeper
    {
        private static IInputProvider _inputProvider;

        public Minesweeper(IInputProvider inputProvider)
        {
            _inputProvider = inputProvider;
        }

        /// <summary>
        /// Play Single Game
        /// </summary>
        /// <param name="minefield"></param>
        /// <param name="gridSize"></param>
        /// <param name="numMines"></param>
        public void PlaySingleGame(char[,] minefield, int gridSize, int numMines)
        {
            bool[,] revealedCells = new bool[gridSize, gridSize];
            while (true)
            {
                DisplayMinefield(minefield, revealedCells);
                string selectedCell = _inputProvider.GetInput();
                int row = selectedCell[0] - 'A';
                int col = int.Parse(selectedCell.Substring(1)) - 1;
                if (TryParseSelectedCell(selectedCell, gridSize, out row, out col))
                {
                    if (minefield[row, col] == 'X')
                    {
                        Console.WriteLine("Oh no, you detonated a mine! Game over.");
                        break;
                    }
                    else
                    {
                        int adjacentMines = CountAdjacentMines(minefield, row, col);

                        if (adjacentMines == 0)
                        {
                            FloodFill(minefield, revealedCells, row, col);
                        }
                        else
                        {
                            revealedCells[row, col] = true;
                            minefield[row, col] = char.Parse(adjacentMines.ToString());
                        }

                        Console.WriteLine($"This square contains {adjacentMines} adjacent mines.");

                        if (CheckFinalGame(minefield, revealedCells, numMines))
                        {
                            DisplayMinefield(minefield, revealedCells);
                            Console.WriteLine("Congratulations, you have won the game!");
                            break;
                        }
                    }
                }
                else 
                {
                    Console.WriteLine("Incorrect Input.");
                }
            }
        }

        /// <summary>
        /// Function to take the initial GRID Configuration input
        /// </summary>
        /// <returns>
        /// Grid Size
        /// </returns>
        public static int CalculateGridSize()
        {
            int minSize = 2;
            int maxSize = 10;
            int gridSize;
            string input;
            do
            {
                Console.WriteLine("Enter the size of the grid (e.g. 4 for a 4x4 grid): ");
                if (int.TryParse(input = Console.ReadLine()!, out gridSize))
                {
                    if (gridSize < minSize)
                    {
                        Console.WriteLine($"Minimum size of grid is {minSize}.");
                    }
                    else if (gridSize > maxSize)
                    {
                        Console.WriteLine($"Maximum size of grid is {maxSize}.");
                    }
                }
                else
                {
                    Console.WriteLine("Incorrect input.");
                }
            } while (!int.TryParse(input, out gridSize) || gridSize < minSize || gridSize > maxSize);

            return gridSize;
        }

        /// <summary>
        /// Function to get the mines and place it into grid
        /// </summary>
        /// <param name="maxMines"></param>
        /// <returns>
        /// Number of mines
        /// </returns>
        public static int CountMinesNumber(int maxMines)
        {
            int minMines = 1;
            int numMines;
            string input;
            do
            {
                Console.WriteLine($"Enter the number of mines (maximum is 35% of the total squares ({maxMines})): ");

                if (int.TryParse(input = Console.ReadLine()!, out numMines))
                {
                    if (numMines < minMines)
                    {
                        Console.WriteLine($"There must be at least 1 mine.");
                    }
                    else if (numMines > maxMines)
                    {
                        Console.WriteLine($"Maximum number is 35% of total squares. ({maxMines})");
                    }
                }
                else
                {
                    Console.WriteLine("Incorect input.");
                }
            } while (!int.TryParse(input, out numMines) || numMines < minMines || numMines > maxMines);

            return numMines;
        }

        /// <summary>
        /// Function to take the InitializeDefaultMinefield
        /// </summary>
        /// <param name="gridSize"></param>
        /// <returns></returns>
        public static char[,] InitializeDefaultMinefield(int gridSize)
        {
            char[,] minefield = new char[gridSize, gridSize];
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    minefield[i, j] = '_';
                }
            }
            return minefield;
        }

        /// <summary>
        /// Function to get the Place Mines
        /// </summary>
        /// <param name="minefield"></param>
        /// <param name="numMines"></param>
        public static void PlaceMines(char[,] minefield, int numMines)
        {
            Random random = new Random();
            int gridSize = minefield.GetLength(0);

            for (int i = 0; i < numMines; i++)
            {
                int row, col;
                do
                {
                    row = random.Next(gridSize);
                    col = random.Next(gridSize);
                } while (minefield[row, col] == 'X');

                minefield[row, col] = 'X';
            }
        }

        /// <summary>
        /// Function to Display the Mine Field
        /// </summary>
        /// <param name="minefield"></param>
        /// <param name="revealedCells"></param>
        static void DisplayMinefield(char[,] minefield, bool[,] revealedCells)
        {
            int gridSize = minefield.GetLength(0);

            Console.WriteLine("\nHere is your minefield:");
            Console.Write("  ");
            for (int col = 0; col < gridSize; col++)
            {
                Console.Write($"{col + 1} ");
            }
            Console.WriteLine();

            for (int row = 0; row < gridSize; row++)
            {
                Console.Write((char)('A' + row) + " ");
                for (int col = 0; col < gridSize; col++)
                {
                    char cell = revealedCells[row, col] ? minefield[row, col] : '_';
                    Console.Write(cell + " ");
                }
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Function to get TryParse Selected Cell
        /// </summary>
        public bool TryParseSelectedCell(string input, int gridSize, out int row, out int col)
        {
            row = -1;
            col = -1;

            bool isValid = !(input.Length < 2 || input.Length > 3 ||
                             input[0] < 'A' || input[0] >= 'A' + gridSize ||
                             input[1] < '1' || input[1] > '0' + gridSize ||
                             (input.Length == 3 && input[2] != '0'));

            if (isValid)
            {
                row = input[0] - 'A';
                col = int.Parse(input[1].ToString()) - 1;
            }

            return isValid;
        }

        /// <summary>
        /// Count Adjacent Mines
        /// </summary>
        /// <param name="minefield"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        static int CountAdjacentMines(char[,] minefield, int row, int col)
        {
            int count = 0;
            int gridSize = minefield.GetLength(0);

            for (int r = Math.Max(row - 1, 0); r <= Math.Min(row + 1, gridSize - 1); r++)
            {
                for (int c = Math.Max(col - 1, 0); c <= Math.Min(col + 1, gridSize - 1); c++)
                {
                    if (r == row && c == col) continue;
                    if (minefield[r, c] == 'X') count++;
                }
            }

            return count;
        }

        /// <summary>
        /// Flood Fill
        /// </summary>
        /// <param name="minefield"></param>
        /// <param name="revealedCells"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        static void FloodFill(char[,] minefield, bool[,] revealedCells, int row, int col)
        {
            int gridSize = minefield.GetLength(0);

            for (int r = Math.Max(row - 1, 0); r <= Math.Min(row + 1, gridSize - 1); r++)
            {
                for (int c = Math.Max(col - 1, 0); c <= Math.Min(col + 1, gridSize - 1); c++)
                {
                    if (!revealedCells[r, c])
                    {
                        revealedCells[r, c] = true;
                        minefield[r, c] = char.Parse(CountAdjacentMines(minefield, r, c).ToString());

                    }
                }
            }
        }

        /// <summary>
        /// Check Final Game 
        /// </summary>
        /// <param name="minefield"></param>
        /// <param name="revealedCells"></param>
        /// <param name="numMines"></param>
        /// <returns></returns>
        static bool CheckFinalGame(char[,] minefield, bool[,] revealedCells, int numMines)
        {
            int gridSize = minefield.GetLength(0);
            int nonMineCount = gridSize * gridSize - numMines;

            int revealedCount = 0;
            for (int row = 0; row < gridSize; row++)
            {
                for (int col = 0; col < gridSize; col++)
                {
                    if (revealedCells[row, col]) revealedCount++;
                }
            }

            return revealedCount == nonMineCount;
        }
    }
}
